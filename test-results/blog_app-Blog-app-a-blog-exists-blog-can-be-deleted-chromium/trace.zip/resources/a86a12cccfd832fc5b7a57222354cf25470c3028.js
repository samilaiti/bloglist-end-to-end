import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8914271b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8914271b"; const useState = __vite__cjsImport3_react["useState"];
const Remove = ({
  user,
  blog,
  deleteItem
}) => {
  console.log("user", user.username);
  console.log("blog user", blog.user.username);
  if (user.username === blog.user.username) {
    const message = `Remove blog ${blog.title} by ${blog.author}`;
    return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: (event) => deleteItem(event, blog.id, message), children: "remove" }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 13,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 12,
      columnNumber: 12
    }, this);
  }
};
_c = Remove;
const Blog = ({
  blog,
  user,
  updateBlog,
  deleteBlog
}) => {
  _s();
  const [showAll, setShowAll] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const toggleShowAll = () => {
    setShowAll(!showAll);
  };
  const addLike = (event, id) => {
    event.preventDefault();
    const updatedBlog = {
      title: blog.title,
      author: blog.author,
      url: blog.url,
      likes: blog.likes + 1,
      user: blog.user
    };
    updateBlog(id, updatedBlog);
  };
  const deleteItem = (event, id, message) => {
    event.preventDefault();
    if (window.confirm(message)) {
      deleteBlog(id);
    }
  };
  if (!showAll) {
    return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", "data-testid": "simpleblog", children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleShowAll, children: "view" }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 56,
        columnNumber: 36
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 55,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", "data-testid": "fullblog", children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleShowAll, children: "hide" }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 60,
        columnNumber: 36
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 60,
        columnNumber: 81
      }, this),
      blog.url,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 61,
        columnNumber: 19
      }, this),
      blog.likes,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: (event) => addLike(event, blog.id), children: "like" }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 62,
        columnNumber: 22
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 62,
        columnNumber: 86
      }, this),
      blog.user.name,
      /* @__PURE__ */ jsxDEV(Remove, { user, blog, deleteItem }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 64,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 59,
      columnNumber: 12
    }, this);
  }
};
_s(Blog, "XC0nqMp5RnZIWkiCcJL//MdTvak=");
_c2 = Blog;
export default Blog;
var _c, _c2;
$RefreshReg$(_c, "Remove");
$RefreshReg$(_c2, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVFIsU0FBU0EsZ0JBQWdCO0FBRXpCLE1BQU1DLFNBQVNBLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFNQztBQUFBQSxFQUFNQztBQUFXLE1BQU07QUFDN0NDLFVBQVFDLElBQUksUUFBUUosS0FBS0ssUUFBUTtBQUNqQ0YsVUFBUUMsSUFBSSxhQUFhSCxLQUFLRCxLQUFLSyxRQUFRO0FBQzNDLE1BQUlMLEtBQUtLLGFBQWFKLEtBQUtELEtBQUtLLFVBQVU7QUFDeEMsVUFBTUMsVUFBVyxlQUFjTCxLQUFLTSxLQUFNLE9BQU1OLEtBQUtPLE1BQU87QUFDNUQsV0FDRSx1QkFBQyxTQUNDLGlDQUFDLFlBQU8sU0FBVUMsV0FBVVAsV0FBV08sT0FBT1IsS0FBS1MsSUFBSUosT0FBTyxHQUFHLHNCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVFLEtBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFDRjtBQUFDSyxLQVhLWjtBQWFOLE1BQU1hLE9BQU9BLENBQUM7QUFBQSxFQUFFWDtBQUFBQSxFQUFNRDtBQUFBQSxFQUFNYTtBQUFBQSxFQUFZQztBQUFXLE1BQU07QUFBQUMsS0FBQTtBQUN2RCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsS0FBSztBQUU1QyxRQUFNb0IsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUMsZ0JBQWdCQSxNQUFNO0FBQzFCUCxlQUFXLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUVBLFFBQU1TLFVBQVVBLENBQUNoQixPQUFPQyxPQUFPO0FBQzdCRCxVQUFNaUIsZUFBZTtBQUVyQixVQUFNQyxjQUFjO0FBQUEsTUFDbEJwQixPQUFPTixLQUFLTTtBQUFBQSxNQUNaQyxRQUFRUCxLQUFLTztBQUFBQSxNQUNib0IsS0FBSzNCLEtBQUsyQjtBQUFBQSxNQUNWQyxPQUFPNUIsS0FBSzRCLFFBQVE7QUFBQSxNQUNwQjdCLE1BQU1DLEtBQUtEO0FBQUFBLElBQ2I7QUFFQWEsZUFBV0gsSUFBSWlCLFdBQVc7QUFBQSxFQUM1QjtBQUVBLFFBQU16QixhQUFhQSxDQUFDTyxPQUFPQyxJQUFJSixZQUFZO0FBQ3pDRyxVQUFNaUIsZUFBZTtBQUNyQixRQUFJSSxPQUFPQyxRQUFRekIsT0FBTyxHQUFHO0FBQzNCUSxpQkFBV0osRUFBRTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBRUEsTUFBSSxDQUFDTSxTQUFTO0FBQ1osV0FDRSx1QkFBQyxTQUFJLE9BQU9FLFdBQVcsV0FBVSxRQUFPLGVBQVksY0FDakRqQjtBQUFBQSxXQUFLTTtBQUFBQSxNQUFNO0FBQUEsTUFBRU4sS0FBS087QUFBQUEsTUFBTztBQUFBLE1BQUMsdUJBQUMsWUFBTyxTQUFTZ0IsZUFBZSxvQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLFNBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUosT0FBTztBQUNMLFdBQ0UsdUJBQUMsU0FBSSxPQUFPTixXQUFXLFdBQVUsUUFBTyxlQUFZLFlBQ2pEakI7QUFBQUEsV0FBS007QUFBQUEsTUFBTTtBQUFBLE1BQUVOLEtBQUtPO0FBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBU2dCLGVBQWUsb0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDMUV2QixLQUFLMkI7QUFBQUEsTUFBSSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ1ozQixLQUFLNEI7QUFBQUEsTUFBTTtBQUFBLE1BQUMsdUJBQUMsWUFBTyxTQUFVcEIsV0FBVWdCLFFBQVFoQixPQUFPUixLQUFLUyxFQUFFLEdBQUcsb0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDakZULEtBQUtELEtBQUtnQztBQUFBQSxNQUNYLHVCQUFDLFVBQU8sTUFBWSxNQUFZLGNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxTQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxFQUVKO0FBQ0Y7QUFBQ2pCLEdBckRLSCxNQUFJO0FBQUFxQixNQUFKckI7QUF1RE4sZUFBZUE7QUFBSSxJQUFBRCxJQUFBc0I7QUFBQUMsYUFBQXZCLElBQUE7QUFBQXVCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlJlbW92ZSIsInVzZXIiLCJibG9nIiwiZGVsZXRlSXRlbSIsImNvbnNvbGUiLCJsb2ciLCJ1c2VybmFtZSIsIm1lc3NhZ2UiLCJ0aXRsZSIsImF1dGhvciIsImV2ZW50IiwiaWQiLCJfYyIsIkJsb2ciLCJ1cGRhdGVCbG9nIiwiZGVsZXRlQmxvZyIsIl9zIiwic2hvd0FsbCIsInNldFNob3dBbGwiLCJibG9nU3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsInRvZ2dsZVNob3dBbGwiLCJhZGRMaWtlIiwicHJldmVudERlZmF1bHQiLCJ1cGRhdGVkQmxvZyIsInVybCIsImxpa2VzIiwid2luZG93IiwiY29uZmlybSIsIm5hbWUiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBSZW1vdmUgPSAoeyB1c2VyLCBibG9nLCBkZWxldGVJdGVtIH0pID0+IHtcbiAgY29uc29sZS5sb2coJ3VzZXInLCB1c2VyLnVzZXJuYW1lKVxuICBjb25zb2xlLmxvZygnYmxvZyB1c2VyJywgYmxvZy51c2VyLnVzZXJuYW1lKVxuICBpZiAodXNlci51c2VybmFtZSA9PT0gYmxvZy51c2VyLnVzZXJuYW1lKSB7XG4gICAgY29uc3QgbWVzc2FnZSA9IGBSZW1vdmUgYmxvZyAke2Jsb2cudGl0bGV9IGJ5ICR7YmxvZy5hdXRob3J9YFxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eyhldmVudCkgPT4gZGVsZXRlSXRlbShldmVudCwgYmxvZy5pZCwgbWVzc2FnZSl9PnJlbW92ZTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG59XG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCB1c2VyLCB1cGRhdGVCbG9nLCBkZWxldGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW3Nob3dBbGwsIHNldFNob3dBbGxdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDVcbiAgfVxuXG4gIGNvbnN0IHRvZ2dsZVNob3dBbGwgPSAoKSA9PiB7XG4gICAgc2V0U2hvd0FsbCghc2hvd0FsbClcbiAgfVxuXG4gIGNvbnN0IGFkZExpa2UgPSAoZXZlbnQsIGlkKSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIC8vIGNvbnNvbGUubG9nKGlkKVxuICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0ge1xuICAgICAgdGl0bGU6IGJsb2cudGl0bGUsXG4gICAgICBhdXRob3I6IGJsb2cuYXV0aG9yLFxuICAgICAgdXJsOiBibG9nLnVybCxcbiAgICAgIGxpa2VzOiBibG9nLmxpa2VzICsgMSxcbiAgICAgIHVzZXI6IGJsb2cudXNlclxuICAgIH1cblxuICAgIHVwZGF0ZUJsb2coaWQsIHVwZGF0ZWRCbG9nKVxuICB9XG5cbiAgY29uc3QgZGVsZXRlSXRlbSA9IChldmVudCwgaWQsIG1lc3NhZ2UpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgKHdpbmRvdy5jb25maXJtKG1lc3NhZ2UpKSB7XG4gICAgICBkZWxldGVCbG9nKGlkKVxuICAgIH1cbiAgfVxuXG4gIGlmICghc2hvd0FsbCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IHN0eWxlPXtibG9nU3R5bGV9IGNsYXNzTmFtZT0nYmxvZycgZGF0YS10ZXN0aWQ9J3NpbXBsZWJsb2cnPlxuICAgICAgICB7YmxvZy50aXRsZX0ge2Jsb2cuYXV0aG9yfSA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVNob3dBbGx9PnZpZXc8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBzdHlsZT17YmxvZ1N0eWxlfSBjbGFzc05hbWU9J2Jsb2cnIGRhdGEtdGVzdGlkPSdmdWxsYmxvZyc+XG4gICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9IDxidXR0b24gb25DbGljaz17dG9nZ2xlU2hvd0FsbH0+aGlkZTwvYnV0dG9uPjxiciAvPlxuICAgICAgICB7YmxvZy51cmx9PGJyIC8+XG4gICAgICAgIHtibG9nLmxpa2VzfSA8YnV0dG9uIG9uQ2xpY2s9eyhldmVudCkgPT4gYWRkTGlrZShldmVudCwgYmxvZy5pZCl9Pmxpa2U8L2J1dHRvbj48YnIgLz5cbiAgICAgICAge2Jsb2cudXNlci5uYW1lfVxuICAgICAgICA8UmVtb3ZlIHVzZXI9e3VzZXJ9IGJsb2c9e2Jsb2d9IGRlbGV0ZUl0ZW09e2RlbGV0ZUl0ZW19IC8+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiL1VzZXJzL3NhbWkvRG9jdW1lbnRzL09waW5ub3QvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==