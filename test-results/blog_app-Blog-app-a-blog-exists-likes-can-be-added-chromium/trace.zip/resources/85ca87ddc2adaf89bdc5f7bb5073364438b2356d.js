import axios from "/node_modules/.vite/deps/axios.js?v=8914271b"
const baseUrl = '/api/users'

const getAll = () => {
  const request = axios.get(baseUrl)
  return request.then(response => response.data)
}

// const getOne = id => {
//   const request = axios.get(`${baseUrl}/`)
// }

export default { getAll }