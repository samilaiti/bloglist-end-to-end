import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8914271b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8914271b"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import LoginForm from "/src/components/LoginForm.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import userService from "/src/services/users.js";
import loginService from "/src/services/login.js";
const Notification = ({
  message,
  messageType
}) => {
  if (message === null) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: messageType, children: message }, void 0, false, {
    fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_c = Notification;
const App = () => {
  _s();
  const [blogVisible, setBlogVisible] = useState(false);
  const [blogs, setBlogs] = useState([]);
  const [newTitle, setNewTitle] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [message, setMessage] = useState(null);
  const [messageType, setMessageType] = useState("success");
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const blogFormRef = useRef();
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
    userService.getAll().then((users2) => setUsers(users2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username: userName,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUserName("");
      setPassword("");
    } catch (exception) {
      setMessageType("error");
      setMessage("wrong credentials");
      setTimeout(() => {
        setMessage(null);
      }, 3e3);
    }
    console.log("logging in with", userName, password);
  };
  const handleLogout = async (event) => {
    event.preventDefault();
    window.localStorage.removeItem("loggedBlogappUser");
    setUser(null);
    setUserName("");
    setPassword("");
  };
  const addBlog = (blogObject) => {
    blogFormRef.current.toggleVisibility();
    blogService.create(blogObject).then((returnedBlog) => {
      setBlogs(blogs.concat(returnedBlog));
      setNewAuthor("");
      setNewTitle("");
      setNewUrl("");
      setMessageType("success");
      setMessage(`a new blog ${blogObject.title} by ${blogObject.author} added`);
      setTimeout(() => {
        setMessage(null);
      }, 3e3);
    }).catch((error) => {
      setMessageType("error");
      setMessage(error.message);
      setTimeout(() => {
        setMessage(null);
      }, 3e3);
    });
  };
  const sortBlogs = () => {
    blogs.sort((a, b) => a.likes - b.likes);
  };
  const updateBlog = (id, blogObject) => {
    console.log("id", id);
    console.log("blog", blogObject);
    blogService.update(id, blogObject).then(blogService.getAll().then((blogs2) => setBlogs(blogs2))).then((returnedBlog) => {
      setBlogs(blogs.map((blog) => blog.id !== returnedBlog.id ? blog : returnedBlog));
    }).catch((error) => {
      setMessageType("error");
      setMessage(error.message);
      setTimeout(() => {
        setMessage(null);
      }, 3e3);
    });
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  };
  const deleteBlog = (id) => {
    blogService.deleteBlog(id);
    const cleanedBlogs = blogs.filter((blog) => blog.id !== id);
    setBlogs(cleanedBlogs);
  };
  const loginForm = () => {
    return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(LoginForm, { handleLogin, handleUsernameChange: ({
      target
    }) => setUserName(target.value), handlePasswordChange: ({
      target
    }) => setPassword(target.value), userName, password }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
      lineNumber: 120,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
      lineNumber: 119,
      columnNumber: 12
    }, this);
  };
  const blogForm = () => {
    sortBlogs();
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
        lineNumber: 130,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        user.name,
        " logged in",
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
          fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
          lineNumber: 133,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
        lineNumber: 138,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
        lineNumber: 137,
        columnNumber: 9
      }, this),
      blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, user, updateBlog, deleteBlog }, blog.id, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
        lineNumber: 140,
        columnNumber: 28
      }, this))
    ] }, void 0, true, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
      lineNumber: 129,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Notification, { message, messageType }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
      lineNumber: 144,
      columnNumber: 7
    }, this),
    !user && loginForm(),
    user && blogForm()
  ] }, void 0, true, {
    fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx",
    lineNumber: 143,
    columnNumber: 10
  }, this);
};
_s(App, "DvabRC+bhJY5rSzJvSIc9xZ/ziA=");
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Notification");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sami/Documents/Opinnot/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZkosU0FBU0EsVUFBVUMsV0FBV0MsY0FBYztBQUM1QyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLGVBQWVBLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFZLE1BQU07QUFDakQsTUFBSUQsWUFBWSxNQUFNO0FBQ3BCLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVdDLGFBQ2JELHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNFLEtBVktIO0FBWU4sTUFBTUksTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJakIsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ2tCLE9BQU9DLFFBQVEsSUFBSW5CLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNvQixVQUFVQyxXQUFXLElBQUlyQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDc0IsV0FBV0MsWUFBWSxJQUFJdkIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3dCLFFBQVFDLFNBQVMsSUFBSXpCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNXLFNBQVNlLFVBQVUsSUFBSTFCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNZLGFBQWFlLGNBQWMsSUFBSTNCLFNBQVMsU0FBUztBQUN4RCxRQUFNLENBQUM0QixVQUFVQyxXQUFXLElBQUk3QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDOEIsVUFBVUMsV0FBVyxJQUFJL0IsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2dDLE1BQU1DLE9BQU8sSUFBSWpDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNrQyxPQUFPQyxRQUFRLElBQUluQyxTQUFTLEVBQUU7QUFFckMsUUFBTW9DLGNBQWNsQyxPQUFPO0FBRTNCRCxZQUFVLE1BQU07QUFDZE0sZ0JBQVk4QixPQUFPLEVBQUVDLEtBQUtwQixZQUN4QkMsU0FBVUQsTUFBTSxDQUNsQjtBQUNBVixnQkFBWTZCLE9BQU8sRUFBRUMsS0FBS0osWUFDeEJDLFNBQVNELE1BQUssQ0FDaEI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMakMsWUFBVSxNQUFNO0FBQ2QsVUFBTXNDLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxtQkFBbUI7QUFDdEUsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1QLFFBQU9XLEtBQUtDLE1BQU1MLGNBQWM7QUFDdENOLGNBQVFELEtBQUk7QUFDWnpCLGtCQUFZc0MsU0FBU2IsTUFBS2MsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1qQixRQUFPLE1BQU12QixhQUFheUMsTUFBTTtBQUFBLFFBQ3BDQyxVQUFVdkI7QUFBQUEsUUFBVUU7QUFBQUEsTUFDdEIsQ0FBQztBQUVEVSxhQUFPQyxhQUFhVyxRQUNsQixxQkFBcUJULEtBQUtVLFVBQVVyQixLQUFJLENBQzFDO0FBQ0F6QixrQkFBWXNDLFNBQVNiLE1BQUtjLEtBQUs7QUFDL0JiLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBU3VCLFdBQVc7QUFDbEIzQixxQkFBZSxPQUFPO0FBQ3RCRCxpQkFBVyxtQkFBbUI7QUFDOUI2QixpQkFBVyxNQUFNO0FBQ2Y3QixtQkFBVyxJQUFJO0FBQUEsTUFDakIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUNBOEIsWUFBUUMsSUFBSSxtQkFBbUI3QixVQUFVRSxRQUFRO0FBQUEsRUFDbkQ7QUFFQSxRQUFNNEIsZUFBZSxPQUFPVixVQUFVO0FBQ3BDQSxVQUFNQyxlQUFlO0FBRXJCVCxXQUFPQyxhQUFha0IsV0FBVyxtQkFBbUI7QUFDbEQxQixZQUFRLElBQUk7QUFDWkosZ0JBQVksRUFBRTtBQUNkRSxnQkFBWSxFQUFFO0FBQUEsRUFDaEI7QUFFQSxRQUFNNkIsVUFBV0MsZ0JBQWU7QUFDOUJ6QixnQkFBWTBCLFFBQVFDLGlCQUFpQjtBQUNyQ3hELGdCQUNHeUQsT0FBT0gsVUFBVSxFQUNqQnZCLEtBQUsyQixrQkFBZ0I7QUFDcEI5QyxlQUFTRCxNQUFNZ0QsT0FBT0QsWUFBWSxDQUFDO0FBQ25DMUMsbUJBQWEsRUFBRTtBQUNmRixrQkFBWSxFQUFFO0FBQ2RJLGdCQUFVLEVBQUU7QUFDWkUscUJBQWUsU0FBUztBQUN4QkQsaUJBQVksY0FBYW1DLFdBQVdNLEtBQU0sT0FBTU4sV0FBV08sTUFBTyxRQUFPO0FBQ3pFYixpQkFBVyxNQUFNO0FBQ2Y3QixtQkFBVyxJQUFJO0FBQUEsTUFDakIsR0FBRyxHQUFJO0FBQUEsSUFDVCxDQUFDLEVBQ0EyQyxNQUFNQyxXQUFTO0FBQ2QzQyxxQkFBZSxPQUFPO0FBQ3RCRCxpQkFBVzRDLE1BQU0zRCxPQUFPO0FBQ3hCNEMsaUJBQVcsTUFBTTtBQUNmN0IsbUJBQVcsSUFBSTtBQUFBLE1BQ2pCLEdBQUcsR0FBSTtBQUFBLElBQ1QsQ0FBQztBQUFBLEVBRUw7QUFFQSxRQUFNNkMsWUFBWUEsTUFBTTtBQUN0QnJELFVBQU1zRCxLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUVFLFFBQVFELEVBQUVDLEtBQUs7QUFBQSxFQUN4QztBQUVBLFFBQU1DLGFBQWFBLENBQUNDLElBQUloQixlQUFlO0FBQ3JDTCxZQUFRQyxJQUFJLE1BQU1vQixFQUFFO0FBQ3BCckIsWUFBUUMsSUFBSSxRQUFRSSxVQUFVO0FBQzlCdEQsZ0JBQ0d1RSxPQUFPRCxJQUFJaEIsVUFBVSxFQUNyQnZCLEtBQ0MvQixZQUFZOEIsT0FBTyxFQUFFQyxLQUFLcEIsWUFDeEJDLFNBQVVELE1BQU0sQ0FDbEIsQ0FDRixFQUNDb0IsS0FBSzJCLGtCQUFnQjtBQUNwQjlDLGVBQVNELE1BQU02RCxJQUFJQyxVQUFRQSxLQUFLSCxPQUFPWixhQUFhWSxLQUFLRyxPQUFPZixZQUFZLENBQUM7QUFBQSxJQUMvRSxDQUFDLEVBQ0FJLE1BQU1DLFdBQVM7QUFDZDNDLHFCQUFlLE9BQU87QUFDdEJELGlCQUFXNEMsTUFBTTNELE9BQU87QUFDeEI0QyxpQkFBVyxNQUFNO0FBQ2Y3QixtQkFBVyxJQUFJO0FBQUEsTUFDakIsR0FBRyxHQUFJO0FBQUEsSUFDVCxDQUFDO0FBQ0huQixnQkFBWThCLE9BQU8sRUFBRUMsS0FBS3BCLFlBQ3hCQyxTQUFVRCxNQUFNLENBQ2xCO0FBQUEsRUFDRjtBQUVBLFFBQU0rRCxhQUFjSixRQUFPO0FBQ3pCdEUsZ0JBQ0cwRSxXQUFXSixFQUFFO0FBRWhCLFVBQU1LLGVBQWVoRSxNQUFNaUUsT0FBT0gsVUFBUUEsS0FBS0gsT0FBT0EsRUFBRTtBQUN4RDFELGFBQVMrRCxZQUFZO0FBQUEsRUFDdkI7QUFFQSxRQUFNRSxZQUFZQSxNQUFNO0FBQ3RCLFdBQ0UsdUJBQUMsU0FDQyxpQ0FBQyxhQUFVLGFBQ1Qsc0JBQXNCLENBQUM7QUFBQSxNQUFFQztBQUFBQSxJQUFPLE1BQU14RCxZQUFZd0QsT0FBT0MsS0FBSyxHQUM5RCxzQkFBc0IsQ0FBQztBQUFBLE1BQUVEO0FBQUFBLElBQU8sTUFBTXRELFlBQVlzRCxPQUFPQyxLQUFLLEdBQzlELFVBQ0EsWUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXFCLEtBTHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLEVBRUo7QUFFQSxRQUFNQyxXQUFXQSxNQUFNO0FBQ3JCaEIsY0FBVTtBQUNWLFdBQ0UsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTO0FBQUEsTUFDVCx1QkFBQyxPQUNFdkM7QUFBQUEsYUFBS3dEO0FBQUFBLFFBQUs7QUFBQSxRQUNYLHVCQUFDLFlBQU8sU0FBUzlCLGNBQWEsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxhQUFVLGFBQVksbUJBQWtCLEtBQUt0QixhQUM1QyxpQ0FBQyxZQUFTLFlBQVl3QixXQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0MxQyxNQUFNNkQsSUFBSUMsVUFDVCx1QkFBQyxRQUFtQixNQUFZLE1BQVksWUFBd0IsY0FBekRBLEtBQUtILElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkYsQ0FDN0Y7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLEVBRUo7QUFDQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxnQkFBYSxTQUFrQixlQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlEO0FBQUEsSUFDeEQsQ0FBQzdDLFFBQVFvRCxVQUFVO0FBQUEsSUFDbkJwRCxRQUFRdUQsU0FBUztBQUFBLE9BSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUN4RSxHQXpLS0QsS0FBRztBQUFBMkUsTUFBSDNFO0FBMktOLGVBQWVBO0FBQUcsSUFBQUQsSUFBQTRFO0FBQUFDLGFBQUE3RSxJQUFBO0FBQUE2RSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJCbG9nIiwiTG9naW5Gb3JtIiwiQmxvZ0Zvcm0iLCJUb2dnbGFibGUiLCJibG9nU2VydmljZSIsInVzZXJTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTm90aWZpY2F0aW9uIiwibWVzc2FnZSIsIm1lc3NhZ2VUeXBlIiwiX2MiLCJBcHAiLCJfcyIsImJsb2dWaXNpYmxlIiwic2V0QmxvZ1Zpc2libGUiLCJibG9ncyIsInNldEJsb2dzIiwibmV3VGl0bGUiLCJzZXROZXdUaXRsZSIsIm5ld0F1dGhvciIsInNldE5ld0F1dGhvciIsIm5ld1VybCIsInNldE5ld1VybCIsInNldE1lc3NhZ2UiLCJzZXRNZXNzYWdlVHlwZSIsInVzZXJOYW1lIiwic2V0VXNlck5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwidXNlciIsInNldFVzZXIiLCJ1c2VycyIsInNldFVzZXJzIiwiYmxvZ0Zvcm1SZWYiLCJnZXRBbGwiLCJ0aGVuIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwidXNlcm5hbWUiLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZXhjZXB0aW9uIiwic2V0VGltZW91dCIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVMb2dvdXQiLCJyZW1vdmVJdGVtIiwiYWRkQmxvZyIsImJsb2dPYmplY3QiLCJjdXJyZW50IiwidG9nZ2xlVmlzaWJpbGl0eSIsImNyZWF0ZSIsInJldHVybmVkQmxvZyIsImNvbmNhdCIsInRpdGxlIiwiYXV0aG9yIiwiY2F0Y2giLCJlcnJvciIsInNvcnRCbG9ncyIsInNvcnQiLCJhIiwiYiIsImxpa2VzIiwidXBkYXRlQmxvZyIsImlkIiwidXBkYXRlIiwibWFwIiwiYmxvZyIsImRlbGV0ZUJsb2ciLCJjbGVhbmVkQmxvZ3MiLCJmaWx0ZXIiLCJsb2dpbkZvcm0iLCJ0YXJnZXQiLCJ2YWx1ZSIsImJsb2dGb3JtIiwibmFtZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBMb2dpbkZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0xvZ2luRm9ybSdcbmltcG9ydCBCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQmxvZ0Zvcm0nXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCB1c2VyU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL3VzZXJzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuXG5jb25zdCBOb3RpZmljYXRpb24gPSAoeyBtZXNzYWdlLCBtZXNzYWdlVHlwZSB9KSA9PiB7XG4gIGlmIChtZXNzYWdlID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e21lc3NhZ2VUeXBlfT5cbiAgICAgIHttZXNzYWdlfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dWaXNpYmxlLCBzZXRCbG9nVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW25ld1RpdGxlLCBzZXROZXdUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25ld0F1dGhvciwgc2V0TmV3QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbmV3VXJsLCBzZXROZXdVcmxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFttZXNzYWdlVHlwZSwgc2V0TWVzc2FnZVR5cGVdID0gdXNlU3RhdGUoJ3N1Y2Nlc3MnKVxuICBjb25zdCBbdXNlck5hbWUsIHNldFVzZXJOYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKVxuXG4gIGNvbnN0IGJsb2dGb3JtUmVmID0gdXNlUmVmKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oYmxvZ3MgPT5cbiAgICAgIHNldEJsb2dzKCBibG9ncyApXG4gICAgKVxuICAgIHVzZXJTZXJ2aWNlLmdldEFsbCgpLnRoZW4odXNlcnMgPT5cbiAgICAgIHNldFVzZXJzKHVzZXJzKVxuICAgIClcbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lOiB1c2VyTmFtZSwgcGFzc3dvcmQsXG4gICAgICB9KVxuXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICdsb2dnZWRCbG9nYXBwVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpXG4gICAgICApXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgc2V0VXNlck5hbWUoJycpXG4gICAgICBzZXRQYXNzd29yZCgnJylcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHNldE1lc3NhZ2VUeXBlKCdlcnJvcicpXG4gICAgICBzZXRNZXNzYWdlKCd3cm9uZyBjcmVkZW50aWFscycpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZShudWxsKVxuICAgICAgfSwgMzAwMClcbiAgICB9XG4gICAgY29uc29sZS5sb2coJ2xvZ2dpbmcgaW4gd2l0aCcsIHVzZXJOYW1lLCBwYXNzd29yZClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcblxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgICBzZXRVc2VyTmFtZSgnJylcbiAgICBzZXRQYXNzd29yZCgnJylcbiAgfVxuXG4gIGNvbnN0IGFkZEJsb2cgPSAoYmxvZ09iamVjdCkgPT4ge1xuICAgIGJsb2dGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgYmxvZ1NlcnZpY2VcbiAgICAgIC5jcmVhdGUoYmxvZ09iamVjdClcbiAgICAgIC50aGVuKHJldHVybmVkQmxvZyA9PiB7XG4gICAgICAgIHNldEJsb2dzKGJsb2dzLmNvbmNhdChyZXR1cm5lZEJsb2cpKVxuICAgICAgICBzZXROZXdBdXRob3IoJycpXG4gICAgICAgIHNldE5ld1RpdGxlKCcnKVxuICAgICAgICBzZXROZXdVcmwoJycpXG4gICAgICAgIHNldE1lc3NhZ2VUeXBlKCdzdWNjZXNzJylcbiAgICAgICAgc2V0TWVzc2FnZShgYSBuZXcgYmxvZyAke2Jsb2dPYmplY3QudGl0bGV9IGJ5ICR7YmxvZ09iamVjdC5hdXRob3J9IGFkZGVkYClcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgc2V0TWVzc2FnZShudWxsKVxuICAgICAgICB9LCAzMDAwKVxuICAgICAgfSlcbiAgICAgIC5jYXRjaChlcnJvciA9PiB7XG4gICAgICAgIHNldE1lc3NhZ2VUeXBlKCdlcnJvcicpXG4gICAgICAgIHNldE1lc3NhZ2UoZXJyb3IubWVzc2FnZSlcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgc2V0TWVzc2FnZShudWxsKVxuICAgICAgICB9LCAzMDAwKVxuICAgICAgfSlcblxuICB9XG5cbiAgY29uc3Qgc29ydEJsb2dzID0gKCkgPT4ge1xuICAgIGJsb2dzLnNvcnQoKGEsIGIpID0+IGEubGlrZXMgLSBiLmxpa2VzKVxuICB9XG5cbiAgY29uc3QgdXBkYXRlQmxvZyA9IChpZCwgYmxvZ09iamVjdCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKCdpZCcsIGlkKVxuICAgIGNvbnNvbGUubG9nKCdibG9nJywgYmxvZ09iamVjdClcbiAgICBibG9nU2VydmljZVxuICAgICAgLnVwZGF0ZShpZCwgYmxvZ09iamVjdClcbiAgICAgIC50aGVuKFxuICAgICAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XG4gICAgICAgICAgc2V0QmxvZ3MoIGJsb2dzIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLnRoZW4ocmV0dXJuZWRCbG9nID0+IHtcbiAgICAgICAgc2V0QmxvZ3MoYmxvZ3MubWFwKGJsb2cgPT4gYmxvZy5pZCAhPT0gcmV0dXJuZWRCbG9nLmlkID8gYmxvZyA6IHJldHVybmVkQmxvZykpXG4gICAgICB9KVxuICAgICAgLmNhdGNoKGVycm9yID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZVR5cGUoJ2Vycm9yJylcbiAgICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKVxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBzZXRNZXNzYWdlKG51bGwpXG4gICAgICAgIH0sIDMwMDApXG4gICAgICB9KVxuICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oYmxvZ3MgPT5cbiAgICAgIHNldEJsb2dzKCBibG9ncyApXG4gICAgKVxuICB9XG5cbiAgY29uc3QgZGVsZXRlQmxvZyA9IChpZCkgPT4ge1xuICAgIGJsb2dTZXJ2aWNlXG4gICAgICAuZGVsZXRlQmxvZyhpZClcblxuICAgIGNvbnN0IGNsZWFuZWRCbG9ncyA9IGJsb2dzLmZpbHRlcihibG9nID0+IGJsb2cuaWQgIT09IGlkKVxuICAgIHNldEJsb2dzKGNsZWFuZWRCbG9ncylcbiAgfVxuXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPExvZ2luRm9ybSBoYW5kbGVMb2dpbj17aGFuZGxlTG9naW59XG4gICAgICAgICAgaGFuZGxlVXNlcm5hbWVDaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VyTmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgIGhhbmRsZVBhc3N3b3JkQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICB1c2VyTmFtZT17dXNlck5hbWV9XG4gICAgICAgICAgcGFzc3dvcmQ9e3Bhc3N3b3JkfVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgY29uc3QgYmxvZ0Zvcm0gPSAoKSA9PiB7XG4gICAgc29ydEJsb2dzKClcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPGgyPmJsb2dzPC9oMj5cbiAgICAgICAgPHA+XG4gICAgICAgICAge3VzZXIubmFtZX0gbG9nZ2VkIGluXG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PlxuICAgICAgICAgICAgbG9nb3V0XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvcD5cbiAgICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cImNyZWF0ZSBuZXcgYmxvZ1wiIHJlZj17YmxvZ0Zvcm1SZWZ9PlxuICAgICAgICAgIDxCbG9nRm9ybSBjcmVhdGVCbG9nPXthZGRCbG9nfSAvPlxuICAgICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgICAge2Jsb2dzLm1hcChibG9nID0+XG4gICAgICAgICAgPEJsb2cga2V5PXtibG9nLmlkfSBibG9nPXtibG9nfSB1c2VyPXt1c2VyfSB1cGRhdGVCbG9nPXt1cGRhdGVCbG9nfSBkZWxldGVCbG9nPXtkZWxldGVCbG9nfSAvPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17bWVzc2FnZX0gbWVzc2FnZVR5cGU9e21lc3NhZ2VUeXBlfSAvPlxuICAgICAgeyF1c2VyICYmIGxvZ2luRm9ybSgpfVxuICAgICAge3VzZXIgJiYgYmxvZ0Zvcm0oKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9Vc2Vycy9zYW1pL0RvY3VtZW50cy9PcGlubm90L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=