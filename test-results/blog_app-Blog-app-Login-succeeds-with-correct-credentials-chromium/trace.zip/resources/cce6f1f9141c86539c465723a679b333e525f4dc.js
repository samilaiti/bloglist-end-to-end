import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8914271b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8914271b"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [newTitle, setNewTitle] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({
      title: newTitle,
      author: newAuthor,
      url: newUrl
    });
    setNewTitle("");
    setNewAuthor("");
    setNewUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "formDiv", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "create new" }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
      "title:",
      /* @__PURE__ */ jsxDEV("input", { value: newTitle, "data-testid": "title", id: "title-id", placeholder: "write title", onChange: (event) => setNewTitle(event.target.value) }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 24,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 24,
        columnNumber: 153
      }, this),
      "author:",
      /* @__PURE__ */ jsxDEV("input", { value: newAuthor, "data-testid": "author", placeholder: "write author", onChange: (event) => setNewAuthor(event.target.value) }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 25,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 25,
        columnNumber: 144
      }, this),
      "url:",
      /* @__PURE__ */ jsxDEV("input", { value: newUrl, "data-testid": "url", placeholder: "write url", onChange: (event) => setNewUrl(event.target.value) }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 26,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 26,
        columnNumber: 129
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "K8n1d7EVyFnsPPMgmWFF2Yqmsas=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJTCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDTSxXQUFXQyxZQUFZLElBQUlQLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNRLFFBQVFDLFNBQVMsSUFBSVQsU0FBUyxFQUFFO0FBRXZDLFFBQU1VLFVBQVdDLFdBQVU7QUFDekJBLFVBQU1DLGVBQWU7QUFDckJWLGVBQVc7QUFBQSxNQUNUVyxPQUFPVDtBQUFBQSxNQUNQVSxRQUFRUjtBQUFBQSxNQUNSUyxLQUFLUDtBQUFBQSxJQUNQLENBQUM7QUFDREgsZ0JBQVksRUFBRTtBQUNkRSxpQkFBYSxFQUFFO0FBQ2ZFLGNBQVUsRUFBRTtBQUFBLEVBQ2Q7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsMkJBQUMsUUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLFVBQUssVUFBVUMsU0FBUTtBQUFBO0FBQUEsTUFDaEIsdUJBQUMsV0FBTSxPQUFPTixVQUFVLGVBQVksU0FBUSxJQUFHLFlBQVcsYUFBWSxlQUFjLFVBQVVPLFdBQVNOLFlBQVlNLE1BQU1LLE9BQU9DLEtBQUssS0FBckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1STtBQUFBLE1BQUcsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQTtBQUFBLE1BQzVJLHVCQUFDLFdBQU0sT0FBT1gsV0FBVyxlQUFZLFVBQVMsYUFBWSxnQkFBZSxVQUFVSyxXQUFTSixhQUFhSSxNQUFNSyxPQUFPQyxLQUFLLEtBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkg7QUFBQSxNQUFHLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUE7QUFBQSxNQUN0SSx1QkFBQyxXQUFNLE9BQU9ULFFBQVEsZUFBWSxPQUFNLGFBQVksYUFBWSxVQUFVRyxXQUFTRixVQUFVRSxNQUFNSyxPQUFPQyxLQUFLLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUg7QUFBQSxNQUFHLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDM0gsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQUo5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUNkLEdBNUJLRixVQUFRO0FBQUFpQixLQUFSakI7QUE4Qk4sZUFBZUE7QUFBUSxJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwiX3MiLCJuZXdUaXRsZSIsInNldE5ld1RpdGxlIiwibmV3QXV0aG9yIiwic2V0TmV3QXV0aG9yIiwibmV3VXJsIiwic2V0TmV3VXJsIiwiYWRkQmxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0aXRsZSIsImF1dGhvciIsInVybCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZ0Zvcm0gPSAoeyBjcmVhdGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW25ld1RpdGxlLCBzZXROZXdUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25ld0F1dGhvciwgc2V0TmV3QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbmV3VXJsLCBzZXROZXdVcmxdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgYWRkQmxvZyA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjcmVhdGVCbG9nKHtcbiAgICAgIHRpdGxlOiBuZXdUaXRsZSxcbiAgICAgIGF1dGhvcjogbmV3QXV0aG9yLFxuICAgICAgdXJsOiBuZXdVcmxcbiAgICB9KVxuICAgIHNldE5ld1RpdGxlKCcnKVxuICAgIHNldE5ld0F1dGhvcignJylcbiAgICBzZXROZXdVcmwoJycpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPSdmb3JtRGl2Jz5cbiAgICAgIDxoMj5jcmVhdGUgbmV3PC9oMj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXthZGRCbG9nfT5cbiAgICAgICAgdGl0bGU6PGlucHV0IHZhbHVlPXtuZXdUaXRsZX0gZGF0YS10ZXN0aWQ9J3RpdGxlJyBpZD0ndGl0bGUtaWQnIHBsYWNlaG9sZGVyPSd3cml0ZSB0aXRsZScgb25DaGFuZ2U9e2V2ZW50ID0+IHNldE5ld1RpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PGJyIC8+XG4gICAgICAgIGF1dGhvcjo8aW5wdXQgdmFsdWU9e25ld0F1dGhvcn0gZGF0YS10ZXN0aWQ9J2F1dGhvcicgcGxhY2Vob2xkZXI9J3dyaXRlIGF1dGhvcicgb25DaGFuZ2U9e2V2ZW50ID0+IHNldE5ld0F1dGhvcihldmVudC50YXJnZXQudmFsdWUpfSAvPjxiciAvPlxuICAgICAgICB1cmw6PGlucHV0IHZhbHVlPXtuZXdVcmx9IGRhdGEtdGVzdGlkPSd1cmwnIHBsYWNlaG9sZGVyPSd3cml0ZSB1cmwnIG9uQ2hhbmdlPXtldmVudCA9PiBzZXROZXdVcmwoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48YnIgLz5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+Y3JlYXRlPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6Ii9Vc2Vycy9zYW1pL0RvY3VtZW50cy9PcGlubm90L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9