import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8914271b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=8914271b"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const LoginForm = ({
  handleLogin,
  handleUsernameChange,
  handlePasswordChange,
  userName,
  password
}) => {
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "log in to application" }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 11,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "username",
      /* @__PURE__ */ jsxDEV("input", { type: "text", "data-testid": "username", value: userName, name: "Username", onChange: handleUsernameChange }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 14,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 12,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "password",
      /* @__PURE__ */ jsxDEV("input", { type: "text", "data-testid": "password", value: password, name: "Password", onChange: handlePasswordChange }, void 0, false, {
        fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 18,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
      fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 20,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
};
_c = LoginForm;
LoginForm.propTypes = {
  handleLogin: PropTypes.func.isRequired,
  handleUsernameChange: PropTypes.func.isRequired,
  handlePasswordChange: PropTypes.func.isRequired,
  userName: PropTypes.string.isRequired,
  password: PropTypes.string.isRequired
};
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sami/Documents/Opinnot/bloglist-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7QUFaUixPQUFPQSxvQkFBZTtBQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVsQyxNQUFNQyxZQUFZQSxDQUFDO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsU0FDQyxpQ0FBQyxVQUFLLFVBQVVKLGFBQ2Q7QUFBQSwyQkFBQyxRQUFHLHFDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxJQUN6Qix1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLGVBQVksWUFDWixPQUFPRyxVQUNQLE1BQUssWUFDTCxVQUFVRix3QkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS2lDO0FBQUEsU0FQbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLGVBQVksWUFDWixPQUFPRyxVQUNQLE1BQUssWUFDTCxVQUFVRix3QkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS2lDO0FBQUEsU0FQbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLE9BdEI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkE7QUFFSjtBQUFDRyxLQW5DS047QUFxQ05BLFVBQVVPLFlBQVk7QUFBQSxFQUNwQk4sYUFBYUYsVUFBVVMsS0FBS0M7QUFBQUEsRUFDNUJQLHNCQUFzQkgsVUFBVVMsS0FBS0M7QUFBQUEsRUFDckNOLHNCQUFzQkosVUFBVVMsS0FBS0M7QUFBQUEsRUFDckNMLFVBQVVMLFVBQVVXLE9BQU9EO0FBQUFBLEVBQzNCSixVQUFVTixVQUFVVyxPQUFPRDtBQUM3QjtBQUVBLGVBQWVUO0FBQVMsSUFBQU07QUFBQUssYUFBQUwsSUFBQSIsIm5hbWVzIjpbIlByb3BUeXBlcyIsIkxvZ2luRm9ybSIsImhhbmRsZUxvZ2luIiwiaGFuZGxlVXNlcm5hbWVDaGFuZ2UiLCJoYW5kbGVQYXNzd29yZENoYW5nZSIsInVzZXJOYW1lIiwicGFzc3dvcmQiLCJfYyIsInByb3BUeXBlcyIsImZ1bmMiLCJpc1JlcXVpcmVkIiwic3RyaW5nIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IExvZ2luRm9ybSA9ICh7XG4gIGhhbmRsZUxvZ2luLFxuICBoYW5kbGVVc2VybmFtZUNoYW5nZSxcbiAgaGFuZGxlUGFzc3dvcmRDaGFuZ2UsXG4gIHVzZXJOYW1lLFxuICBwYXNzd29yZFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgICA8aDI+bG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT0ndGV4dCdcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSd1c2VybmFtZSdcbiAgICAgICAgICAgIHZhbHVlPXt1c2VyTmFtZX1cbiAgICAgICAgICAgIG5hbWU9J1VzZXJuYW1lJ1xuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVVzZXJuYW1lQ2hhbmdlfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIHBhc3N3b3JkXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPSd0ZXh0J1xuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJ1xuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgbmFtZT0nUGFzc3dvcmQnXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGFzc3dvcmRDaGFuZ2V9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT0nc3VibWl0Jz5sb2dpbjwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbkxvZ2luRm9ybS5wcm9wVHlwZXMgPSB7XG4gIGhhbmRsZUxvZ2luOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBoYW5kbGVVc2VybmFtZUNoYW5nZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgaGFuZGxlUGFzc3dvcmRDaGFuZ2U6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIHVzZXJOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIHBhc3N3b3JkOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWRcbn1cblxuZXhwb3J0IGRlZmF1bHQgTG9naW5Gb3JtIl0sImZpbGUiOiIvVXNlcnMvc2FtaS9Eb2N1bWVudHMvT3Bpbm5vdC9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Mb2dpbkZvcm0uanN4In0=